﻿using IntenseApi.Database;
using IntenseApi.Model;
using IntenseApi.Services;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace TestIntens
{
    public class SkillServiceTests
    {
        [Fact]
        public void GetSkillById_SuccesfullyFound()
        {
            var options = new DbContextOptionsBuilder<HrDbContext>()
                .UseInMemoryDatabase("TestDb").Options;
            using (var context = new HrDbContext(options))
            {
                var service = new SkillService(context);
                var skill = new Skill()
                {
                    Name = "Test",

                };
                context.Skills.Add(skill);
                context.SaveChanges();
                var can = service.GetSkillById(1);
                Assert.NotNull(can);
            }
        }
        [Fact]
        public void RemoveSkill_SuccesfullyRemoved()
        {
            var options = new DbContextOptionsBuilder<HrDbContext>()
                .UseInMemoryDatabase("TestDb").Options;
            using (var context = new HrDbContext(options))
            {
                var service = new SkillService(context);
                var skill = new Skill()
                {
                    Name= "Test",


                };
                var skill2 = new Skill()
                {
                    Name = "Test2",


                };
                context.Skills.Add(skill);
                context.Skills.Add(skill2);
                context.SaveChanges();
                service.RemoveSkill(2);
                Assert.Equal(1, context.Skills.Count());
            }
        }
    }
}
