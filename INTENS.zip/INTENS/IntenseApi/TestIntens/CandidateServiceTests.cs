﻿using IntenseApi.Database;
using IntenseApi.Model;
using IntenseApi.Services;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace TestIntens
{
    public class CandidateServiceTests
    {
        [Fact]
        public void CreateCandidate_SuccessfullyAdd()
        {
            var options = new DbContextOptionsBuilder<HrDbContext>()
                .UseInMemoryDatabase("TestDb").Options;
            using (var context = new HrDbContext(options)) 
            {
                var service = new CandidateService(context);
                var candidate = new Candidate()
                {
                    FullName = "Test",
                    DateOfBirth = DateTime.UtcNow,
                    PhoneNumber = "Test",
                    Email = "Test",
                    Skills = new List<Skill>() { }


                };
                service.CreateCandidate(candidate);

                Assert.Equal(1,context.Candidates.Count());
            } 

        }

        [Fact]
        public void DeleteCandidate_SuccesfullyDeleted()
        {
            var options = new DbContextOptionsBuilder<HrDbContext>()
                .UseInMemoryDatabase("TestDb").Options;
            using (var context = new HrDbContext(options))
            {
                var service = new CandidateService(context);
                var candidate = new Candidate()
                {
                    FullName = "Test",
                    DateOfBirth = DateTime.UtcNow,
                    PhoneNumber = "Test",
                    Email = "Test",
                    Skills = new List<Skill>() { }


                };
                var candidate2 = new Candidate()
                {
                    FullName = "Test2",
                    DateOfBirth = DateTime.UtcNow,
                    PhoneNumber = "Test2",
                    Email = "Test2",
                    Skills = new List<Skill>() { }


                };
                context.Candidates.Add(candidate);
                context.Candidates.Add(candidate2);
                context.SaveChanges();
                service.DeleteCandidate(2);
                Assert.Equal(1,context.Candidates.Count());
            }
        }

        [Fact]
        public void GetCandidateById_SuccesfullyFound()
        {
            var options = new DbContextOptionsBuilder<HrDbContext>()
                .UseInMemoryDatabase("TestDb").Options;
            using (var context = new HrDbContext(options))
            {
                var service = new CandidateService(context);
                var candidate = new Candidate()
                {
                    FullName = "Test",
                    DateOfBirth = DateTime.UtcNow,
                    PhoneNumber = "Test",
                    Email = "Test",
                    Skills = new List<Skill>() { }


                };
                context.Candidates.Add(candidate);
                context.SaveChanges();
                var can = service.GetCandidateById(1);
                Assert.NotNull(can);
            }
        }
        [Fact]
        public void GetCandidates_SuccesfullyFound()
        {
            var options = new DbContextOptionsBuilder<HrDbContext>()
                .UseInMemoryDatabase("TestDb").Options;
            using (var context = new HrDbContext(options))
            {
                var service = new CandidateService(context);
                var candidate = new Candidate()
                {
                    FullName = "Test",
                    DateOfBirth = DateTime.UtcNow,
                    PhoneNumber = "Test",
                    Email = "Test",
                    Skills = new List<Skill>() { }
                    

                };
                context.Candidates.Add(candidate);
                context.SaveChanges();
                var can = service.GetCandidates(null,null);
                Assert.Equal(1,can.Count());
            }
        }
        [Fact]
        public void UpdateCandidate_SuccesfullyUpdated()
        {
            var options = new DbContextOptionsBuilder<HrDbContext>()
                .UseInMemoryDatabase("TestDb").Options;
            using (var context = new HrDbContext(options))
            {
                var service = new CandidateService(context);
                var candidate = new Candidate()
                {
                    FullName = "Test",
                    DateOfBirth = DateTime.UtcNow,
                    PhoneNumber = "Test",
                    Email = "Test",
                    Skills = new List<Skill>() { }


                };
                context.Candidates.Add(candidate);
                context.SaveChanges();
                candidate.Email = "Email";
                service.UpdateCandidate(1, candidate);
                Assert.Equal("Email",context.Candidates.FirstOrDefault().Email);
            }
        }
        [Fact]
        public void DeleteSkillFromCandidate_SeccesfullyDeleted()
        {
            var options = new DbContextOptionsBuilder<HrDbContext>()
                 .UseInMemoryDatabase("TestDb").Options;
            using (var context = new HrDbContext(options))
            {
                var service = new CandidateService(context);
                var candidate = new Candidate()
                {
                    FullName = "Test",
                    DateOfBirth = DateTime.UtcNow,
                    PhoneNumber = "Test",
                    Email = "Test",
                    Skills = new List<Skill>() 
                    {
                        new Skill()
                        {
                            Name = "English"
                        },
                        new Skill()
                        {
                            Name = "Russian"
                        }
                    }


                };
                context.Candidates.Add(candidate);
                context.SaveChanges();
                service.DeleteSkillFromCandidate(candidate, 1);
                Assert.Equal("Russian", context.Candidates.FirstOrDefault().Skills.FirstOrDefault().Name);

            }
        }
    }
}
