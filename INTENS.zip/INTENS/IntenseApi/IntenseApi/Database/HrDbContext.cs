﻿using IntenseApi.Model;
using Microsoft.EntityFrameworkCore;

namespace IntenseApi.Database
{
    public class HrDbContext : DbContext
    {
        public HrDbContext(DbContextOptions<HrDbContext> options)
        : base(options)
        
        {
            
        }
        public DbSet<Skill> Skills { get; set; }

        public DbSet<Candidate> Candidates { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Candidate>().HasMany(C => C.Skills).WithMany(s=>s.Candidates);
        }
    }
}
