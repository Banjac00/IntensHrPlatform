﻿using IntenseApi.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace IntenseApi.DTO
{
    public class CandidateDTO
    {
        [Required]
        public string FullName { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        public DateTime DateOfBirth { get; set; }
        [Required]
        public string PhoneNumber { get; set; }
        [Required]
        public List<Skill> Skills { get; set; }
    }
}
