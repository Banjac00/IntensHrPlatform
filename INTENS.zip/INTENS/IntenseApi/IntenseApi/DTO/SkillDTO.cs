﻿using System.ComponentModel.DataAnnotations;

namespace IntenseApi.DTO
{
    public class SkillDTO
    {
        [Required]
        public int CandidateId { get; set; }
        [Required]
        public int SkillId { get; set; }

    }
}
