﻿using IntenseApi.Database;
using IntenseApi.Model;
using Microsoft.AspNetCore.Routing.Matching;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace IntenseApi.Services
{
    public class CandidateService : ICandidateService
    {
        private readonly HrDbContext dbContext;

        public CandidateService(HrDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public Candidate CreateCandidate(Candidate candidate) 
        {
            foreach(var skill in candidate.Skills)
            {
                dbContext.Entry(skill).State = EntityState.Unchanged;
            }
            dbContext.Candidates.Add(candidate);
            dbContext.SaveChanges();
            return candidate;

        }

        public void DeleteCandidate(int id) /*Remove/Delete*/
        {
            var candidate = dbContext.Candidates.FirstOrDefault(c => c.Id == id);
            dbContext.Candidates.Remove(candidate);
            dbContext.SaveChanges();
        }

        public void DeleteSkillFromCandidate(Candidate candidate, int skillId)
        {
            candidate.Skills = candidate.Skills.Where(c => c.Id != skillId).ToList();
            dbContext.SaveChanges();
        }

        public Candidate GetCandidateById(int id) /*Find =>*/
        {
           return dbContext.Candidates.Include(c=>c.Skills).FirstOrDefault(c => c.Id == id);
            
        }

        public IEnumerable<Candidate> GetCandidates(string candidateName,string skillName)
        {
            var query = dbContext.Candidates.AsQueryable();
            if(candidateName != null)
            {
                query = query.Where(c => c.FullName.Contains(candidateName));
            }

            if(skillName != null)
            {
                query = query.Where(c => c.Skills.Any(s=>s.Name.Contains(skillName)));
            }
           return query.Include(c=>c.Skills).ToList();
        }

        public Candidate UpdateCandidate(int id, Candidate candidate)
        {
            var dbCandidate = dbContext.Candidates.Include(c=>c.Skills).Single(c => c.Id == id);
            dbCandidate.FullName = candidate.FullName;
            dbCandidate.DateOfBirth = candidate.DateOfBirth;
            dbCandidate.Email = candidate.Email;
            dbCandidate.PhoneNumber = candidate.PhoneNumber;

            dbCandidate.Skills.Clear();
            foreach (var skill in candidate.Skills.ToList())
            {
                dbCandidate.Skills.Add(skill);
            }

            dbContext.Candidates.Update(dbCandidate);
            dbContext.SaveChanges();
            return candidate;
        }
        public bool CheckIfExists(int candidateId)
        {
            return dbContext.Candidates.Any(c => c.Id == candidateId);
        }
    }
}
