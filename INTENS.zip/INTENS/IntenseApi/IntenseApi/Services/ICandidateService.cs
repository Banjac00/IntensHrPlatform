﻿using IntenseApi.Model;
using System.Collections;
using System.Collections.Generic;
using System.Web;

namespace IntenseApi.Services
{
    public interface ICandidateService
    {
        IEnumerable<Candidate> GetCandidates(string candidateName, string skillName);

        Candidate GetCandidateById(int id);
        Candidate CreateCandidate(Candidate candidate);

        Candidate UpdateCandidate(int id, Candidate candidate);
        void DeleteSkillFromCandidate(Candidate candidate, int skillId);
        bool CheckIfExists(int candidateId);
        void DeleteCandidate(int id);

    }
}
