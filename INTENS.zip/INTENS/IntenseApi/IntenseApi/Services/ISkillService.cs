﻿using IntenseApi.Model;

namespace IntenseApi.Services
{
    public interface ISkillService
    {
        Skill GetSkillById(int skillId);

        void RemoveSkill(int skillId);
    }
}
