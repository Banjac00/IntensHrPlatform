﻿using IntenseApi.Database;
using IntenseApi.Model;
using Microsoft.AspNetCore.Routing.Matching;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace IntenseApi.Services
{
    public class SkillService : ISkillService
    {
        private readonly HrDbContext hrDbContext;

        public SkillService(HrDbContext hrDbContext) 
        {
            this.hrDbContext = hrDbContext;
        }
        public Skill GetSkillById(int skillId)
        {
            return hrDbContext.Skills.FirstOrDefault(c => c.Id == skillId);
        }

        public void RemoveSkill(int skillId)
        {
            hrDbContext.Skills.FirstOrDefault(c => c.Id == skillId);
            var skill = hrDbContext.Skills.FirstOrDefault(c => c.Id == skillId);
            hrDbContext.Skills.Remove(skill);
            hrDbContext.SaveChanges();
        }
    }
}
