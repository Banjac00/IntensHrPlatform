﻿using AutoMapper;
using IntenseApi.DTO;
using IntenseApi.Model;

namespace IntenseApi.AutoMapper
{
    public class CandidateProfile : Profile
    {
        public CandidateProfile() 
        {
            CreateMap<Candidate, CandidateDTO>().ReverseMap();
            CreateMap<Skill, SkillDTO>().ReverseMap();
        }

    }
}
