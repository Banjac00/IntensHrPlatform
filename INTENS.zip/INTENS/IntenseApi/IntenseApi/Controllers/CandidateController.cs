﻿using AutoMapper;
using IntenseApi.DTO;
using IntenseApi.Model;
using IntenseApi.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Linq;

namespace IntenseApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CandidateController : ControllerBase
    {
        private readonly ICandidateService candidateService;
        private readonly IMapper mapper;
        private readonly ISkillService skillService;

        public CandidateController(ICandidateService candidateService,IMapper mapper, ISkillService skillService)
        {
            this.candidateService = candidateService;
            this.mapper = mapper;
            this.skillService = skillService;
        }
        [HttpGet]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult GetAllCandidates([FromQuery]string candidateName,[FromQuery]string skillName)
        {
            return Ok(candidateService.GetCandidates(candidateName, skillName));
        }

        [HttpGet("{id}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult GetCandidateById(int id) 
        {
            var candidate = candidateService.GetCandidateById(id);
            if (candidate == null)
            {
                return NotFound ();
            }
            return Ok(candidate);
        }

        [HttpPost]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult CreateCandidate([FromBody] CandidateDTO candidateDTO) 
        {
            if (!ModelState.IsValid) 
            {
                return BadRequest(ModelState);
            }
            var candidate = mapper.Map<Candidate>(candidateDTO);
            try
            {

                candidateService.CreateCandidate(candidate);

            }
            catch 
            { 
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
            return Ok(candidate);
            
        }

        [HttpPut("{id}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult UpdateCandidate(int id, [FromBody]CandidateDTO candidateDTO)
        {
            var doesExist = candidateService.CheckIfExists(id);
            if (!doesExist)
            {
                return NotFound();
            }
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var dbCandidate = mapper.Map<Candidate>(candidateDTO);
            try
            {
                candidateService.UpdateCandidate(id, dbCandidate);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
              return NoContent();
        }

        [HttpDelete("{id}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult DeleteCandidate(int id)
        {
            var candidate = candidateService.GetCandidateById(id);
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            candidateService.DeleteCandidate(id);
            return NoContent();
        }

        [HttpPost("skill")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult CreateSkillForCandidate([FromBody]SkillDTO skillDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var candidate = candidateService.GetCandidateById(skillDTO.CandidateId);
            if (candidate == null)
            {
                return NotFound();
            }

            var skill = skillService.GetSkillById(skillDTO.SkillId);
            if(skill == null)
            {
                return NotFound();
            }
            if(candidate.Skills.Any(c=>c.Id == skill.Id))
            {
                return BadRequest("Skill already exists");
            }

            candidate.Skills.Add(skill);
            candidateService.UpdateCandidate(skillDTO.CandidateId, candidate);
            return Ok();
        }
        [HttpPut("skill/{skillId}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult RemoveSkill(int skillId)
        {
            var skill = skillService.GetSkillById(skillId);
            if (skill == null)
            {
                return NotFound();
            }
            skillService.RemoveSkill(skillId);
            return NoContent();
        }

        [HttpPut("{id}/skill/{skillId}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult DeleteSkillFromCandidate(int id, int skillId)
        {
            var candidate = candidateService.GetCandidateById(id);
            if (candidate == null)
            {
                return NotFound();
            }

            var skillExists = candidate.Skills.Any(c => c.Id == skillId);
            if (!skillExists)
            {
                return NotFound();
            }
            candidateService.DeleteSkillFromCandidate(candidate, skillId);
            return NoContent();
        }

    }
}