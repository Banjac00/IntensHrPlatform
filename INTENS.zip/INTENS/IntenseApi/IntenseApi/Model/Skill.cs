﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace IntenseApi.Model
{
    public class Skill
    {
        public int Id { get; set; }
        public string Name { get; set; }
        [JsonIgnore]
        public List<Candidate> Candidates { get; set; }
    }


}
